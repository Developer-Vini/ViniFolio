import HeroText from "../components/HeroText";
import ParalaxBackground from "../components/ParalaxBackground";
import { Laptop } from "../components/Laptop";

const Hero = () => {
    return <section className="flex items-start justify-center md:items-start md:justify-start min-h-screen overflow-hidden c-space">
        <ParalaxBackground />
        <HeroText />

        <figure className="absolute inset-0 w-full h-full">
            <Canvas camera={{ position: [0, 3, 9], fov: 45 }}>
                <ambientLight intensity={1.5} />
                <directionalLight position={[5, 8, 5]} intensity={2} />
                <Suspense fallback={null}>
                    <Laptop position={[0, -1.5, 0]} />
                </Suspense>
            </Canvas>
        </figure>


    </section>
};

export default Hero;